# PLOT CODE for 'An adaptive weight ensemble approach to forecast influenza activity in the context of irregular seasonality.'
# Author: QR Du

Rscript Figure/Fig_main.R